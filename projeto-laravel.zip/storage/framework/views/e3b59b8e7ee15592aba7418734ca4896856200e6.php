<?php $__env->startSection('cabecalho'); ?>
Adicionar Séries
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>

<?php echo $__env->make("erros", ['errors'=> $errors] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('series.store')); ?>" method="post" enctype="multipart/form-data" >
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col col-8">
            <label for="nome">Nome</label>
            <input type="text" class="form-control" id="nome" name="nome">
        </div>
        <div class="col col-2">
            <label for="qtd_temporadas">Nº Premporadas</label>
            <input type="number" class="form-control" id="qtd_temporadas" name="qtd_temporadas">
        </div>
        <div class="col col-2">
            <label for="ep_por_temporada">Ep. por temporada</label>
            <input type="bumber" class="form-control" id="ep_por_temporada" name="ep_por_temporada">
        </div>
    </div>

    <div class="row">
        <div class="col col-12">
            <label for="capa">Capa</label>
            <input type="file" class="form-control" id="capa" name="capa">
        </div>
    </div>

    <button class="btn btn-primary mt-2">Adicionar</button>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Estudos\PHP\Alura\projeto-laravel\resources\views/series/create.blade.php ENDPATH**/ ?>