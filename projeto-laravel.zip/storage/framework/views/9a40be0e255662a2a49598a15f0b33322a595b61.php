<?php $__env->startSection('cabecalho'); ?>
    Temporadas de <?php echo e($serie->nome); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <?php if($serie->capa): ?>
    <div class="row">
        <div class="col-md-12 text-center mb-4">
            <a href="<?php echo e($serie->capa_url); ?>" target="_blank">
                <img src="<?php echo e($serie->capa_url); ?>" class="img-thumbnail" height="400px" width="400px" alt="">
            </a>

        </div>
    </div>
    <?php endif; ?>

    <ul class="list-group">
        <?php $__currentLoopData = $temporadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temporada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <a href="/temporadas/<?php echo e($temporada->id); ?>/episodios">Temporada <?php echo e($temporada->numero); ?></a>
            <span class="badge badge-secondary"><?php echo e($temporada->getEpisodiosAssistidos()->count()); ?> / <?php echo e($temporada->episodios->count()); ?></span>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Estudos\PHP\Alura\projeto-laravel\resources\views/temporadas/index.blade.php ENDPATH**/ ?>