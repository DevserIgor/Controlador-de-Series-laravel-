<?php if(!empty($mensagem)): ?>
    <div class="alert alert-success">
        <?php echo e($mensagem); ?>

    </div>
<?php endif; ?>
<?php /**PATH E:\Estudos\PHP\Alura\projeto-laravel\resources\views/mensagem.blade.php ENDPATH**/ ?>