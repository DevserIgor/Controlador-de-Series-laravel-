<?php $__env->startSection('cabecalho'); ?>
    Episódios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <form method="post">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">Nome</label>
            <input type="name" name="name" id="name" required class="form-control">
        </div>

        <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" name="email" id="email" required class="form-control">
        </div>

        <div class="form-group">
            <label for="password">Senha</label>
            <input type="password" name="password" id="password" required min="1" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary mt-3">
            Registrar-se
        </button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Estudos\PHP\Alura\projeto-laravel\resources\views/registro/create.blade.php ENDPATH**/ ?>