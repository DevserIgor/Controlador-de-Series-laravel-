<?php $__env->startComponent('mail::message'); ?>

# Nova série
## Nome da serie : <?php echo e($nomeSerie); ?>

## Qtd Tempordas : <?php echo e($qtdTemporadas); ?>

## Qtd Episódios : <?php echo e($qtdEpisodios); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH E:\Estudos\PHP\Alura\projeto-laravel\resources\views/mail/serie/nova-serie.blade.php ENDPATH**/ ?>