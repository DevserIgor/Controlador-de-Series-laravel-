@component('mail::message')

# Nova série
## Nome da serie : {{$nomeSerie}}
## Qtd Tempordas : {{$qtdTemporadas}}
## Qtd Episódios : {{$qtdEpisodios}}
@endcomponent
